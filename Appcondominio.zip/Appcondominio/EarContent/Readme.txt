Integrantes:
Carlos Cumbal
Leonardo Aguagallo
William Puma